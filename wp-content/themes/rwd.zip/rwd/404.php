<?php get_header(); ?>

<div class="content-wrap">
    <div class="content container clearfix">
        <div class="row">
            <div class="page-content col-md-12">

                <h1>Błąd 404</h1>
                <h2>Żądany dokument nie został odnaleziony</h2>
                <p>Skorzystaj z wyszukiwarki:</p>
                <?php get_search_form(); ?>

            </div>

            <!-- Content End -->


        </div>
    </div>
</div>

<?php get_footer(); ?>
