<?php

namespace Share\Includes\Interfaces;

interface LoaderInterface {
   public function run();
}