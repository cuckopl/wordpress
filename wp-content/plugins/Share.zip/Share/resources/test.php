<?php
echo"ala ma kota ";