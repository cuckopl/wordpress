<?php

namespace Share\Main;

class RssPlugin extends \Share\Includes\Plugin\PluginManager {

    public function __construct() {
        $this->addLoader(new RssLoader());
    }

}
