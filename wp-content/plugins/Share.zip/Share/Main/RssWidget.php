<?php

namespace Share\Main;

class RssWidget extends \Share\Includes\Widget\AbstractWidget {

    public function __construct($id_base = '', $name = '', $widget_options = array(), $control_options = array()) {
        return parent::__construct('RssWidget', 'Advanced Rss Widget', array('description' => 'ALA MA KOTA'), $control_options);
    }

    public function form($instance) {
        $defaults = array(
            'title' => 'RSS FEEDS',
            'rss_feed' => 'adres url rss',
            'rss_items' => 2
        );
        $instance = wp_parse_args((array) $instance, $defaults);

        echo $this->renderView(PLUGIN_PATH . '/resources/rss-widget-form.php', array_merge($instance, array('widget' => $this)));
    }

    public function update($newInstance, $oldInstance) {
        return $newInstance;
    }

    public function widget($arg, $instance) {
        return $instance;
    }

}
