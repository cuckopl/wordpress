<?php

define("PLUGIN_PATH", __DIR__);
//start auto loader
require_once __DIR__ . '/Includes/autoload.php';

/**
 * @package Share
 */
/*
  Plugin Name: RSS PARSER
  Plugin URI: RSS PARSER
  Description: RSS PARSER
  Author: RSS PARSER
  Author URI: RSS PARSER
  License: RSS PARSER
  Text Domain: RSS PARSER
 */




$rssParser = Share\PluginFactory\RssPluginFactory::make();
$rssParser->run();


